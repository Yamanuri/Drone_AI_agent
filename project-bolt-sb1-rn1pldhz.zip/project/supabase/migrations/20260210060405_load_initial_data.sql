/*
  # Load Initial Data

  1. Insert pilot roster
  2. Insert drone fleet
  3. Insert missions
*/

INSERT INTO pilots (id, name, skills, certifications, location, status, current_assignment, available_from) VALUES
('P001', 'Arjun', ARRAY['Mapping', 'Survey'], ARRAY['DGCA', 'Night Ops'], 'Bangalore', 'Available', NULL, '2026-02-05'),
('P002', 'Neha', ARRAY['Inspection'], ARRAY['DGCA'], 'Mumbai', 'Assigned', 'Project-A', '2026-02-12'),
('P003', 'Rohit', ARRAY['Inspection', 'Mapping'], ARRAY['DGCA'], 'Mumbai', 'Available', NULL, '2026-02-05'),
('P004', 'Sneha', ARRAY['Survey', 'Thermal'], ARRAY['DGCA', 'Night Ops'], 'Bangalore', 'On Leave', NULL, '2026-02-15')
ON CONFLICT DO NOTHING;

INSERT INTO drones (id, model, capabilities, status, location, current_assignment, maintenance_due) VALUES
('D001', 'DJI M300', ARRAY['LiDAR', 'RGB'], 'Available', 'Bangalore', NULL, '2026-03-01'),
('D002', 'DJI Mavic 3', ARRAY['RGB'], 'Maintenance', 'Mumbai', NULL, '2026-02-01'),
('D003', 'DJI Mavic 3T', ARRAY['Thermal'], 'Available', 'Mumbai', NULL, '2026-04-01'),
('D004', 'Autel Evo II', ARRAY['Thermal', 'RGB'], 'Available', 'Bangalore', NULL, '2026-03-15')
ON CONFLICT DO NOTHING;

INSERT INTO missions (id, client, location, required_skills, required_certs, start_date, end_date, priority) VALUES
('PRJ001', 'Client A', 'Bangalore', ARRAY['Mapping'], ARRAY['DGCA'], '2026-02-06', '2026-02-08', 'High'),
('PRJ002', 'Client B', 'Mumbai', ARRAY['Inspection'], ARRAY['DGCA', 'Night Ops'], '2026-02-07', '2026-02-09', 'Urgent'),
('PRJ003', 'Client C', 'Bangalore', ARRAY['Thermal'], ARRAY['DGCA'], '2026-02-10', '2026-02-12', 'Standard')
ON CONFLICT DO NOTHING;
