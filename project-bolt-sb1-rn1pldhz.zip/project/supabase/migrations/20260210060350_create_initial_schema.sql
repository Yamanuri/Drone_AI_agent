/*
  # Drone Operations Coordinator Schema

  1. New Tables
    - `pilots` - Pilot roster with skills and availability
    - `drones` - Drone fleet inventory with capabilities
    - `missions` - Project missions with requirements
    - `assignments` - Pilot-drone-mission assignments
    - `coordinator_logs` - Conversation history and decisions

  2. Security
    - Enable RLS on all tables
    - Public read access for mission coordination data
    - Authenticated users can create/update assignments
*/

CREATE TABLE IF NOT EXISTS pilots (
  id text PRIMARY KEY,
  name text NOT NULL,
  skills text[] NOT NULL,
  certifications text[] NOT NULL,
  location text NOT NULL,
  status text NOT NULL DEFAULT 'Available',
  current_assignment text,
  available_from text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS drones (
  id text PRIMARY KEY,
  model text NOT NULL,
  capabilities text[] NOT NULL,
  status text NOT NULL DEFAULT 'Available',
  location text NOT NULL,
  current_assignment text,
  maintenance_due text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS missions (
  id text PRIMARY KEY,
  client text NOT NULL,
  location text NOT NULL,
  required_skills text[] NOT NULL,
  required_certs text[] NOT NULL,
  start_date text NOT NULL,
  end_date text NOT NULL,
  priority text NOT NULL DEFAULT 'Standard',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mission_id text NOT NULL REFERENCES missions(id),
  pilot_id text NOT NULL REFERENCES pilots(id),
  drone_id text NOT NULL REFERENCES drones(id),
  status text NOT NULL DEFAULT 'proposed',
  notes text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(mission_id, pilot_id, drone_id)
);

CREATE TABLE IF NOT EXISTS coordinator_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_type text NOT NULL,
  content text NOT NULL,
  context jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE pilots ENABLE ROW LEVEL SECURITY;
ALTER TABLE drones ENABLE ROW LEVEL SECURITY;
ALTER TABLE missions ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE coordinator_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Pilots are publicly readable"
  ON pilots FOR SELECT
  USING (true);

CREATE POLICY "Drones are publicly readable"
  ON drones FOR SELECT
  USING (true);

CREATE POLICY "Missions are publicly readable"
  ON missions FOR SELECT
  USING (true);

CREATE POLICY "Assignments are publicly readable"
  ON assignments FOR SELECT
  USING (true);

CREATE POLICY "Anyone can create assignments"
  ON assignments FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Assignments can be updated"
  ON assignments FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Coordinator logs are publicly readable"
  ON coordinator_logs FOR SELECT
  USING (true);

CREATE POLICY "Anyone can create coordinator logs"
  ON coordinator_logs FOR INSERT
  WITH CHECK (true);

CREATE INDEX idx_pilots_location ON pilots(location);
CREATE INDEX idx_pilots_status ON pilots(status);
CREATE INDEX idx_pilots_skills ON pilots USING GIN(skills);
CREATE INDEX idx_drones_location ON drones(location);
CREATE INDEX idx_drones_status ON drones(status);
CREATE INDEX idx_drones_capabilities ON drones USING GIN(capabilities);
CREATE INDEX idx_missions_priority ON missions(priority);
CREATE INDEX idx_missions_location ON missions(location);
CREATE INDEX idx_missions_skills ON missions USING GIN(required_skills);
CREATE INDEX idx_assignments_mission ON assignments(mission_id);
CREATE INDEX idx_assignments_pilot ON assignments(pilot_id);
CREATE INDEX idx_assignments_drone ON assignments(drone_id);
