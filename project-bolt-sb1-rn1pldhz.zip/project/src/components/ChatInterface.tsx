import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader } from 'lucide-react';
import { CoordinatorMessage } from '../types';
import { coordinatorService } from '../services/coordinator_service';
import { missionService } from '../services/mission_service';
import { pilotService } from '../services/pilot_service';
import { droneService } from '../services/drone_service';
import { supabase } from '../services/supabase';

export const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<CoordinatorMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Welcome to the Drone Operations Coordinator! I can help you with pilot assignments, drone allocation, conflict detection, and mission coordination. What would you like to do today?',
      timestamp: new Date().toISOString(),
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: CoordinatorMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    await supabase
      .from('coordinator_logs')
      .insert([{
        message_type: 'user',
        content: input,
      }])
      .catch(() => { });

    try {
      const response = await generateResponse(input);
      const assistantMessage: CoordinatorMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, assistantMessage]);

      await supabase
        .from('coordinator_logs')
        .insert([{
          message_type: 'assistant',
          content: response,
        }])
        .catch(() => { });
    } catch (error) {
      const errorMessage: CoordinatorMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'I encountered an error processing your request. Please try again.',
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const generateResponse = async (query: string): Promise<string> => {
    const { action, context } = coordinatorService.parseUserQuery(query);

    if (action === 'list_available') {
      const pilots = await pilotService.getAvailablePilots();
      const drones = await droneService.getAvailableDrones();

      if (pilots.length === 0 && drones.length === 0) {
        return 'Currently, no pilots or drones are available for immediate assignment.';
      }

      let response = '';
      if (pilots.length > 0) {
        response += `**Available Pilots:**\n${pilots.map(p => `- ${p.name} (${p.location}, Skills: ${p.skills.join(', ')})`).join('\n')}\n\n`;
      }
      if (drones.length > 0) {
        response += `**Available Drones:**\n${drones.map(d => `- ${d.model} (${d.location}, Capabilities: ${d.capabilities.join(', ')})`).join('\n')}`;
      }
      return response;
    }

    if (action === 'check_conflicts') {
      const missions = await missionService.getAllMissions();
      if (missions.length === 0) return 'No missions found to check for conflicts.';

      const upcomingMissions = await missionService.getUpcomingMissions();
      if (upcomingMissions.length === 0) {
        return 'No upcoming missions with potential conflicts detected.';
      }

      let conflicts = '';
      for (const mission of upcomingMissions.slice(0, 3)) {
        const bestAssignment = await coordinatorService.findBestAssignment(mission);
        if (bestAssignment) {
          conflicts += `- **${mission.client}** (${mission.location}, Priority: ${mission.priority}): Best match is ${bestAssignment.pilot.name} with ${bestAssignment.drone.model} (Feasibility: ${bestAssignment.feasibility_score}%)\n`;
        } else {
          conflicts += `- **${mission.client}**: No suitable pilot-drone pairing found\n`;
        }
      }
      return `**Mission Assignment Status:**\n${conflicts}`;
    }

    if (action === 'get_status') {
      const missions = await missionService.getActiveMissions();
      const pilots = await pilotService.getAllPilots();
      const assignedPilots = pilots.filter(p => p.status === 'Assigned').length;

      return `**Operations Status:**\n- Active Missions: ${missions.length}\n- Assigned Pilots: ${assignedPilots}/${pilots.length}\n- Available Pilots: ${pilots.length - assignedPilots}\n\nUse "show available" to see who's free, or "check conflicts" for mission status.`;
    }

    if (action === 'urgent_reassign') {
      const urgentMissions = await missionService.getMissionsByPriority('Urgent');
      if (urgentMissions.length === 0) {
        return 'No urgent missions requiring immediate reassignment.';
      }

      const mission = urgentMissions[0];
      const proposals = await coordinatorService.proposeAssignments(mission);

      if (proposals.length === 0) {
        return `⚠️ **URGENT:** Mission for ${mission.client} in ${mission.location} has no available resources. Recommend contacting management for escalation.`;
      }

      const best = proposals[0];
      return `⚠️ **URGENT ASSIGNMENT RECOMMENDED:**\n- Mission: ${mission.client}\n- Recommended Pilot: ${best.pilot.name}\n- Drone: ${best.drone.model}\n- Feasibility: ${best.feasibility_score}%\n- Action: Execute assignment immediately`;
    }

    return `I can help with:\n- **"show available"** - List available pilots and drones\n- **"check conflicts"** - Review mission assignments\n- **"status"** - Operations overview\n- **"urgent"** - Handle urgent missions\n\nWhat would you like to do?`;
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-2xl rounded-lg p-4 ${
                message.role === 'user'
                  ? 'bg-blue-600 text-white rounded-br-none'
                  : 'bg-white text-slate-900 shadow-md rounded-bl-none border border-slate-200'
              }`}
            >
              <p className="text-sm md:text-base leading-relaxed whitespace-pre-wrap">
                {message.content}
              </p>
              <p className={`text-xs mt-2 ${
                message.role === 'user' ? 'text-blue-100' : 'text-slate-500'
              }`}>
                {new Date(message.timestamp).toLocaleTimeString()}
              </p>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white text-slate-900 shadow-md rounded-lg rounded-bl-none p-4 flex items-center gap-2">
              <Loader className="w-4 h-4 animate-spin" />
              <span className="text-sm">Processing...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="border-t border-slate-200 bg-white p-4 md:p-6">
        <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto">
          <div className="flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about assignments, conflicts, availability..."
              disabled={loading}
              className="flex-1 px-4 py-3 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-100"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white px-6 py-3 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Send</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
