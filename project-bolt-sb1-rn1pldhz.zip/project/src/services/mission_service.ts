import { supabase } from './supabase';
import { Mission } from '../types';

export const missionService = {
  async getAllMissions(): Promise<Mission[]> {
    const { data, error } = await supabase
      .from('missions')
      .select('*')
      .order('start_date');

    if (error) throw error;
    return data || [];
  },

  async getMissionById(id: string): Promise<Mission | null> {
    const { data, error } = await supabase
      .from('missions')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async getActiveMissions(): Promise<Mission[]> {
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('missions')
      .select('*')
      .lte('start_date', today)
      .gte('end_date', today)
      .order('priority');

    if (error) throw error;
    return data || [];
  },

  async getUpcomingMissions(days: number = 7): Promise<Mission[]> {
    const today = new Date();
    const future = new Date(today.getTime() + days * 24 * 60 * 60 * 1000);
    const todayStr = today.toISOString().split('T')[0];
    const futureStr = future.toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('missions')
      .select('*')
      .gte('start_date', todayStr)
      .lte('start_date', futureStr)
      .order('priority');

    if (error) throw error;
    return data || [];
  },

  async getMissionsByLocation(location: string): Promise<Mission[]> {
    const { data, error } = await supabase
      .from('missions')
      .select('*')
      .eq('location', location)
      .order('start_date');

    if (error) throw error;
    return data || [];
  },

  async getMissionsByPriority(priority: string): Promise<Mission[]> {
    const { data, error } = await supabase
      .from('missions')
      .select('*')
      .eq('priority', priority)
      .order('start_date');

    if (error) throw error;
    return data || [];
  },

  async getMissionsBySkill(skill: string): Promise<Mission[]> {
    const { data, error } = await supabase
      .from('missions')
      .select('*')
      .contains('required_skills', [skill])
      .order('start_date');

    if (error) throw error;
    return data || [];
  },
};
