import { supabase } from './supabase';
import { Assignment } from '../types';

export const assignmentService = {
  async getAllAssignments(): Promise<Assignment[]> {
    const { data, error } = await supabase
      .from('assignments')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async getAssignmentById(id: string): Promise<Assignment | null> {
    const { data, error } = await supabase
      .from('assignments')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async getAssignmentsByMission(missionId: string): Promise<Assignment[]> {
    const { data, error } = await supabase
      .from('assignments')
      .select('*')
      .eq('mission_id', missionId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async getAssignmentsByPilot(pilotId: string): Promise<Assignment[]> {
    const { data, error } = await supabase
      .from('assignments')
      .select('*')
      .eq('pilot_id', pilotId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async getAssignmentsByDrone(droneId: string): Promise<Assignment[]> {
    const { data, error } = await supabase
      .from('assignments')
      .select('*')
      .eq('drone_id', droneId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async createAssignment(assignment: Omit<Assignment, 'id' | 'created_at'>): Promise<Assignment> {
    const { data, error } = await supabase
      .from('assignments')
      .insert([assignment])
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateAssignmentStatus(id: string, status: string): Promise<void> {
    const { error } = await supabase
      .from('assignments')
      .update({ status })
      .eq('id', id);

    if (error) throw error;
  },

  async updateAssignmentNotes(id: string, notes: string): Promise<void> {
    const { error } = await supabase
      .from('assignments')
      .update({ notes })
      .eq('id', id);

    if (error) throw error;
  },

  async deleteAssignment(id: string): Promise<void> {
    const { error } = await supabase
      .from('assignments')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },
};
