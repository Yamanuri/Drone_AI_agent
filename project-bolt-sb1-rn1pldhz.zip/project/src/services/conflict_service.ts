import { Pilot, Drone, Mission, ConflictCheck, ConflictType } from '../types';

export const conflictService = {
  checkSkillMatch(pilot: Pilot, mission: Mission): ConflictCheck {
    const hasAllSkills = mission.required_skills.every(skill =>
      pilot.skills.some(ps => ps.toLowerCase().includes(skill.toLowerCase()))
    );

    if (!hasAllSkills) {
      const missing = mission.required_skills.filter(
        skill => !pilot.skills.some(ps => ps.toLowerCase().includes(skill.toLowerCase()))
      );
      return {
        type: 'skill_mismatch',
        severity: 'high',
        message: `Pilot missing skills: ${missing.join(', ')}`
      };
    }

    return { type: 'none', severity: 'low', message: 'Skills matched' };
  },

  checkCertifications(pilot: Pilot, mission: Mission): ConflictCheck {
    const hasAllCerts = mission.required_certs.every(cert =>
      pilot.certifications.some(pc => pc.toLowerCase().includes(cert.toLowerCase()))
    );

    if (!hasAllCerts) {
      const missing = mission.required_certs.filter(
        cert => !pilot.certifications.some(pc => pc.toLowerCase().includes(cert.toLowerCase()))
      );
      return {
        type: 'skill_mismatch',
        severity: 'high',
        message: `Pilot missing certifications: ${missing.join(', ')}`
      };
    }

    return { type: 'none', severity: 'low', message: 'Certifications matched' };
  },

  checkLocationMatch(pilot: Pilot, mission: Mission): ConflictCheck {
    if (pilot.location !== mission.location) {
      return {
        type: 'location_mismatch',
        severity: 'medium',
        message: `Location mismatch: pilot in ${pilot.location}, mission in ${mission.location}`
      };
    }

    return { type: 'none', severity: 'low', message: 'Location matched' };
  },

  checkPilotAvailability(pilot: Pilot, missionStartDate: string): ConflictCheck {
    if (pilot.status !== 'Available') {
      return {
        type: 'unavailable',
        severity: 'high',
        message: `Pilot status: ${pilot.status}. Available from: ${pilot.available_from}`
      };
    }

    const pilotAvailableDate = new Date(pilot.available_from);
    const missionDate = new Date(missionStartDate);

    if (pilotAvailableDate > missionDate) {
      return {
        type: 'unavailable',
        severity: 'high',
        message: `Pilot available after mission start date`
      };
    }

    return { type: 'none', severity: 'low', message: 'Pilot is available' };
  },

  checkDroneAvailability(drone: Drone): ConflictCheck {
    if (drone.status !== 'Available') {
      return {
        type: 'maintenance',
        severity: 'high',
        message: `Drone status: ${drone.status}. Maintenance due: ${drone.maintenance_due}`
      };
    }

    return { type: 'none', severity: 'low', message: 'Drone is available' };
  },

  checkDroneCapabilities(drone: Drone, mission: Mission): ConflictCheck {
    const missionRequiresCapabilities = ['Thermal', 'LiDAR', 'RGB'];
    const requiredForMission = missionRequiresCapabilities.filter(cap =>
      mission.required_skills.some(skill => skill.toLowerCase().includes(cap.toLowerCase()))
    );

    if (requiredForMission.length === 0) {
      return { type: 'none', severity: 'low', message: 'No specific capabilities required' };
    }

    const hasCapabilities = requiredForMission.every(cap =>
      drone.capabilities.some(dc => dc.toLowerCase().includes(cap.toLowerCase()))
    );

    if (!hasCapabilities) {
      const missing = requiredForMission.filter(
        cap => !drone.capabilities.some(dc => dc.toLowerCase().includes(cap.toLowerCase()))
      );
      return {
        type: 'skill_mismatch',
        severity: 'high',
        message: `Drone missing capabilities: ${missing.join(', ')}`
      };
    }

    return { type: 'none', severity: 'low', message: 'Drone capabilities matched' };
  },

  checkDroneLocation(drone: Drone, mission: Mission): ConflictCheck {
    if (drone.location !== mission.location) {
      return {
        type: 'location_mismatch',
        severity: 'medium',
        message: `Drone location mismatch: drone in ${drone.location}, mission in ${mission.location}`
      };
    }

    return { type: 'none', severity: 'low', message: 'Drone location matched' };
  },

  calculateFeasibilityScore(conflicts: ConflictCheck[]): number {
    const severityScores = { low: 100, medium: 75, high: 25 };
    const baseScore = 100;
    const penalties = conflicts.reduce((sum, conflict) => {
      if (conflict.type === 'none') return sum;
      return sum + (100 - severityScores[conflict.severity]);
    }, 0);

    return Math.max(0, baseScore - penalties);
  }
};
