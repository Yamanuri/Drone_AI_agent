import { Pilot, Drone, Mission, AssignmentProposal } from '../types';
import { conflictService } from './conflict_service';
import { pilotService } from './pilot_service';
import { droneService } from './drone_service';

export const coordinatorService = {
  async proposeAssignments(mission: Mission): Promise<AssignmentProposal[]> {
    const pilots = await pilotService.getAllPilots();
    const drones = await droneService.getAllDrones();

    const proposals: AssignmentProposal[] = [];

    for (const pilot of pilots) {
      for (const drone of drones) {
        const conflicts = [
          conflictService.checkSkillMatch(pilot, mission),
          conflictService.checkCertifications(pilot, mission),
          conflictService.checkLocationMatch(pilot, mission),
          conflictService.checkPilotAvailability(pilot, mission.start_date),
          conflictService.checkDroneAvailability(drone),
          conflictService.checkDroneCapabilities(drone, mission),
          conflictService.checkDroneLocation(drone, mission),
        ];

        const feasibilityScore = conflictService.calculateFeasibilityScore(conflicts);

        if (feasibilityScore >= 50) {
          proposals.push({
            mission,
            pilot,
            drone,
            conflicts: conflicts.filter(c => c.type !== 'none'),
            feasibility_score: feasibilityScore
          });
        }
      }
    }

    return proposals.sort((a, b) => b.feasibility_score - a.feasibility_score);
  },

  async findBestAssignment(mission: Mission): Promise<AssignmentProposal | null> {
    const proposals = await this.proposeAssignments(mission);
    return proposals.length > 0 ? proposals[0] : null;
  },

  async findAlternativeAssignments(mission: Mission, excludePilotId: string): Promise<AssignmentProposal[]> {
    const proposals = await this.proposeAssignments(mission);
    return proposals.filter(p => p.pilot.id !== excludePilotId);
  },

  generateReassignmentStrategy(currentAssignment: AssignmentProposal, urgentMission: Mission): string {
    const reasons = [];

    if (urgentMission.priority === 'Urgent') {
      reasons.push(`Urgent mission (Priority: ${urgentMission.priority}) requires immediate reassignment`);
    }

    if (currentAssignment.feasibility_score < 60) {
      reasons.push(`Current assignment has lower feasibility score (${currentAssignment.feasibility_score}%)`);
    }

    reasons.push(`Reassign pilot ${currentAssignment.pilot.name} to new mission ${urgentMission.client}`);
    reasons.push(`Provide drone replacement if available in ${currentAssignment.pilot.location}`);

    return reasons.join('. ');
  },

  parseUserQuery(query: string): {
    action: string;
    context: { mission_id?: string; pilot_id?: string; drone_id?: string };
  } {
    const lowerQuery = query.toLowerCase();

    if (
      lowerQuery.includes('assign') ||
      lowerQuery.includes('assign') ||
      lowerQuery.includes('allocate')
    ) {
      return { action: 'assign', context: {} };
    }

    if (lowerQuery.includes('conflict') || lowerQuery.includes('issue')) {
      return { action: 'check_conflicts', context: {} };
    }

    if (lowerQuery.includes('available') || lowerQuery.includes('free')) {
      return { action: 'list_available', context: {} };
    }

    if (lowerQuery.includes('status')) {
      return { action: 'get_status', context: {} };
    }

    if (lowerQuery.includes('urgent') || lowerQuery.includes('emergency')) {
      return { action: 'urgent_reassign', context: {} };
    }

    return { action: 'general_query', context: {} };
  },
};
