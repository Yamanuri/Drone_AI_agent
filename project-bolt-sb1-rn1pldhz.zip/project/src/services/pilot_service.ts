import { supabase } from './supabase';
import { Pilot } from '../types';

export const pilotService = {
  async getAllPilots(): Promise<Pilot[]> {
    const { data, error } = await supabase
      .from('pilots')
      .select('*')
      .order('name');

    if (error) throw error;
    return data || [];
  },

  async getPilotById(id: string): Promise<Pilot | null> {
    const { data, error } = await supabase
      .from('pilots')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async getAvailablePilots(): Promise<Pilot[]> {
    const { data, error } = await supabase
      .from('pilots')
      .select('*')
      .eq('status', 'Available')
      .order('name');

    if (error) throw error;
    return data || [];
  },

  async getPilotsByLocation(location: string): Promise<Pilot[]> {
    const { data, error } = await supabase
      .from('pilots')
      .select('*')
      .eq('location', location)
      .order('name');

    if (error) throw error;
    return data || [];
  },

  async getPilotsBySkill(skill: string): Promise<Pilot[]> {
    const { data, error } = await supabase
      .from('pilots')
      .select('*')
      .contains('skills', [skill])
      .order('name');

    if (error) throw error;
    return data || [];
  },

  async updatePilotStatus(id: string, status: string): Promise<void> {
    const { error } = await supabase
      .from('pilots')
      .update({ status })
      .eq('id', id);

    if (error) throw error;
  },

  async assignPilotToMission(pilotId: string, missionId: string): Promise<void> {
    const { error } = await supabase
      .from('pilots')
      .update({
        current_assignment: missionId,
        status: 'Assigned'
      })
      .eq('id', pilotId);

    if (error) throw error;
  },

  async unassignPilot(pilotId: string): Promise<void> {
    const { error } = await supabase
      .from('pilots')
      .update({
        current_assignment: null,
        status: 'Available'
      })
      .eq('id', pilotId);

    if (error) throw error;
  },
};
