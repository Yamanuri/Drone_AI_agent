import { supabase } from './supabase';
import { Drone } from '../types';

export const droneService = {
  async getAllDrones(): Promise<Drone[]> {
    const { data, error } = await supabase
      .from('drones')
      .select('*')
      .order('model');

    if (error) throw error;
    return data || [];
  },

  async getDroneById(id: string): Promise<Drone | null> {
    const { data, error } = await supabase
      .from('drones')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async getAvailableDrones(): Promise<Drone[]> {
    const { data, error } = await supabase
      .from('drones')
      .select('*')
      .eq('status', 'Available')
      .order('model');

    if (error) throw error;
    return data || [];
  },

  async getDronesByLocation(location: string): Promise<Drone[]> {
    const { data, error } = await supabase
      .from('drones')
      .select('*')
      .eq('location', location)
      .order('model');

    if (error) throw error;
    return data || [];
  },

  async getDronesByCapability(capability: string): Promise<Drone[]> {
    const { data, error } = await supabase
      .from('drones')
      .select('*')
      .contains('capabilities', [capability])
      .order('model');

    if (error) throw error;
    return data || [];
  },

  async updateDroneStatus(id: string, status: string): Promise<void> {
    const { error } = await supabase
      .from('drones')
      .update({ status })
      .eq('id', id);

    if (error) throw error;
  },

  async assignDroneToMission(droneId: string, missionId: string): Promise<void> {
    const { error } = await supabase
      .from('drones')
      .update({
        current_assignment: missionId,
        status: 'In Use'
      })
      .eq('id', droneId);

    if (error) throw error;
  },

  async unassignDrone(droneId: string): Promise<void> {
    const { error } = await supabase
      .from('drones')
      .update({
        current_assignment: null,
        status: 'Available'
      })
      .eq('id', droneId);

    if (error) throw error;
  },
};
