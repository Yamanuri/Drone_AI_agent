export type PilotStatus = 'Available' | 'Assigned' | 'On Leave';
export type DroneStatus = 'Available' | 'Maintenance' | 'In Use';
export type MissionPriority = 'Standard' | 'High' | 'Urgent';
export type ConflictType = 'skill_mismatch' | 'location_mismatch' | 'unavailable' | 'maintenance' | 'none';

export interface Pilot {
  id: string;
  name: string;
  skills: string[];
  certifications: string[];
  location: string;
  status: PilotStatus;
  current_assignment: string | null;
  available_from: string;
}

export interface Drone {
  id: string;
  model: string;
  capabilities: string[];
  status: DroneStatus;
  location: string;
  current_assignment: string | null;
  maintenance_due: string;
}

export interface Mission {
  id: string;
  client: string;
  location: string;
  required_skills: string[];
  required_certs: string[];
  start_date: string;
  end_date: string;
  priority: MissionPriority;
}

export interface Assignment {
  id: string;
  mission_id: string;
  pilot_id: string;
  drone_id: string;
  status: 'proposed' | 'confirmed' | 'completed' | 'cancelled';
  created_at: string;
  notes: string;
}

export interface ConflictCheck {
  type: ConflictType;
  severity: 'low' | 'medium' | 'high';
  message: string;
}

export interface AssignmentProposal {
  mission: Mission;
  pilot: Pilot;
  drone: Drone;
  conflicts: ConflictCheck[];
  feasibility_score: number;
}

export interface CoordinatorMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  context?: {
    mission_id?: string;
    pilot_id?: string;
    drone_id?: string;
    assignment_id?: string;
  };
}
